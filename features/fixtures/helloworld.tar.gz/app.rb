require 'sinatra'

get '/' do
  who = 'second'

  "hello #{who}!\n"
end
